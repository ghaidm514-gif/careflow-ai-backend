# CareFlow AI — Backend Integration Guide (Phase B)

Hand this file to the FastAPI team. The Lovable frontend is frozen; the backend must match this contract exactly.

---

## 1. CORS

Add CORS middleware to FastAPI. Allow the local dev origins plus the Lovable preview/published domains.

```python
# main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:3000",
        "http://localhost:8080",
    ],
    allow_origin_regex=r"https://.*\.lovable\.(app|dev|host)|https://.*\.lovableproject\.com",
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Accept"],
)
```

Notes:
- `allow_credentials=False` — the frontend does not send cookies or auth headers.
- The regex covers Lovable preview subdomains (`*.lovableproject.com`, `*.lovable.app`, etc.).
- Preflight `OPTIONS` is handled automatically by `CORSMiddleware`.

---

## 2. API Contract

Base URL prefix: **`/api/v1`**
All requests and responses are JSON (`Content-Type: application/json`).

### 2.1 `POST /api/v1/sessions`

Create a new session. Called once when the app boots (or on restart).

Request:
```json
{ "language": "en" }        // "en" | "ar"
```

Response `200`:
```json
{
  "session_id": "uuid-string",
  "created_at": "2026-07-19T11:28:29Z"   // optional ISO-8601
}
```

### 2.2 `POST /api/v1/triage/requests`

Submit the user's first complaint. Starts a triage flow.

Request:
```json
{
  "session_id": "uuid-string",
  "complaint": "free-text chief complaint",
  "language": "en"
}
```

Response `200`: **`TriageRequest`** (see §3).
- `status` will be `"IN_PROGRESS"` and `next_question` will be populated, **or**
- `status` will be `"COMPLETED"` (skip chat, go straight to recommendation).

### 2.3 `POST /api/v1/triage/requests/{request_id}/answers`

Submit an answer to the currently-displayed question.

Request:
```json
{
  "question_id": "q1",
  "answer_id": "a",              // optional — from the option list
  "answer_text": "Less than 1 hour ago"   // optional free text / label
}
```

Response `200`: **`TriageRequest`** with the next question, or `status: "COMPLETED"`.

### 2.4 `GET /api/v1/triage/requests/{request_id}`

Fetch the current state of a triage request. Used by Chat / Recommendation / Summary screens.

Response `200`: **`TriageRequest`**.

---

## 3. `TriageRequest` schema

```ts
type TriageStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "FAILED";

interface BackendOption {
  id: string;
  label: string;
  description?: string;
  icon?: string;              // optional icon key
}

interface BackendQuestion {
  id: string;
  category?: string;          // shown as small caption above the question
  text: string;
  options: BackendOption[];
}

interface TriageAnswerRecord {
  question_id: string;
  question_text: string;
  answer_id?: string;
  answer_text: string;
}

interface TriageRequest {
  request_id: string;
  session_id: string;
  status: TriageStatus;

  chief_complaint?: string;
  next_question?: BackendQuestion | null;   // present iff status === "IN_PROGRESS"
  answers?: TriageAnswerRecord[];

  // Populated when status === "COMPLETED"
  triage_category?: string;                 // e.g. "Moderate"
  recommended_destination?: string;         // e.g. "Urgent Care Clinic"
  urgency_level?: "low" | "moderate" | "high" | "emergency";
  urgency_label?: string;                   // localized short label
  action?: string;                          // "Visit an urgent care clinic within 24 hours"
  service?: string;
  wait?: string;                            // e.g. "About 30–45 min"
  rating?: number;                          // 1..5 confidence
  reason?: string;                          // short rationale
  safety_rule?: string | null;              // triggered safety rule, if any
  ai_summary?: string;                      // 1–3 sentence summary for Visit Summary

  created_at?: string;                      // ISO-8601
  updated_at?: string;                      // ISO-8601
}
```

### Error responses

Any non-2xx response should be JSON:
```json
{ "detail": "human-readable message" }
```
The frontend surfaces `detail` (or `message`) in the retry UI.

---

## 4. Status values & frontend navigation

| Endpoint returns `status`    | Frontend behavior                                     |
| ---------------------------- | ----------------------------------------------------- |
| `IN_PROGRESS` + `next_question` | Stay on / navigate to `/chat`, render `next_question` |
| `COMPLETED`                     | Auto-navigate to `/recommendation`                    |
| `FAILED`                        | Show error view with "Try again"                      |
| `PENDING`                       | Show loading spinner, poll `GET /triage/requests/{id}` |

**Restart flow:** frontend clears local `session_id` and calls `POST /sessions` again. A brand-new session is expected — no server-side restart endpoint required.

**Visit Summary** (`/summary`) uses the same `GET /triage/requests/{id}` and reads: `triage_category`, `recommended_destination`, `chief_complaint`, `answers`, `safety_rule`, `ai_summary`, `updated_at`.

---

## 5. Environment configuration (frontend side)

The frontend reads the backend URL from a Vite env var. Add to the Lovable project's `.env`:

```
VITE_API_BASE_URL=https://your-fastapi-host.example.com
```

- No trailing slash.
- If unset, the frontend falls back to an in-memory mock backend (useful for design review, not for the demo).
- After changing `.env`, restart the dev server.

For a locally-running FastAPI:
```
VITE_API_BASE_URL=http://localhost:8000
```

---

## 6. Minimal TypeScript client (reference)

The frontend already ships this client (`src/lib/api.ts`). Reproduced here so the backend team can validate request/response shapes.

```ts
const BASE = import.meta.env.VITE_API_BASE_URL as string;
const PREFIX = "/api/v1";

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(`${BASE}${PREFIX}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...(init.headers || {}),
    },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail ?? body.message ?? `Request failed (${res.status})`);
  }
  return res.json() as Promise<T>;
}

export const api = {
  createSession: (language: "en" | "ar") =>
    request<Session>("/sessions", { method: "POST", body: JSON.stringify({ language }) }),

  createTriageRequest: (session_id: string, complaint: string, language: "en" | "ar") =>
    request<TriageRequest>("/triage/requests", {
      method: "POST",
      body: JSON.stringify({ session_id, complaint, language }),
    }),

  submitAnswer: (
    request_id: string,
    payload: { question_id: string; answer_id?: string; answer_text?: string },
  ) =>
    request<TriageRequest>(`/triage/requests/${request_id}/answers`, {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  getTriageRequest: (request_id: string) =>
    request<TriageRequest>(`/triage/requests/${request_id}`),
};
```

---

## 7. Smoke test

Once CORS + endpoints are deployed, verify from a browser tab open at a Lovable preview URL:

```js
await fetch("https://your-fastapi-host.example.com/api/v1/sessions", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ language: "en" }),
}).then(r => r.json());
// => { session_id: "...", created_at: "..." }
```

If that returns a `session_id` with no CORS error in the console, the frontend is ready to integrate — set `VITE_API_BASE_URL` and every screen works end-to-end.

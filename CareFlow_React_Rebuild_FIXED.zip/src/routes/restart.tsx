import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { CheckCircle2, RotateCcw, Home, Loader2 } from "lucide-react";
import { Screen, IconTile } from "@/components/Screen";
import { useI18n } from "@/lib/i18n";
import { api, ApiError } from "@/lib/api";
import { sessionStore } from "@/lib/session";

export const Route = createFileRoute("/restart")({
  head: () => ({
    meta: [
      { title: "Restart Assessment — CareFlow AI" },
      { name: "description", content: "Start a fresh CareFlow AI symptom assessment session." },
      { property: "og:title", content: "Restart Assessment — CareFlow AI" },
      { property: "og:description", content: "Start a fresh symptom assessment session." },
      { property: "og:url", content: "https://flow-caretaker-ghiadm514.lovable.app/restart" },
    ],
    links: [{ rel: "canonical", href: "https://flow-caretaker-ghiadm514.lovable.app/restart" }],
  }),
  component: RestartPage,
});

function RestartPage() {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startNew = async () => {
    setBusy(true);
    setError(null);
    try {
      sessionStore.clearAll();
      const s = await api.createSession(lang);
      sessionStore.setSessionId(s.session_id);
      navigate({ to: "/" });
    } catch (e) {
      setError(e instanceof ApiError ? e.message : t("err.offline"));
    } finally {
      setBusy(false);
    }
  };


  return (
    <Screen>
      <div className="flex flex-1 flex-col items-center justify-center text-center">
        <IconTile tone="primary" size="lg" className="!size-20 [&>svg]:!size-10">
          <CheckCircle2 />
        </IconTile>
        <h1 className="mt-6 text-3xl font-extrabold">{t("restart.title")}</h1>
        <p className="mt-3 max-w-xs text-base text-muted-foreground">{t("restart.subtitle")}</p>
        {error && (
          <div className="mt-4 rounded-2xl bg-warning-soft px-4 py-2 text-xs font-semibold text-warning">
            {error}
          </div>
        )}
      </div>

      <div className="flex flex-col gap-3">
        <button
          onClick={startNew}
          disabled={busy}
          className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-semibold text-primary-foreground shadow-glow-primary transition active:scale-[0.98] disabled:opacity-60"
        >
          {busy ? <Loader2 className="size-5 animate-spin" /> : <RotateCcw className="size-5" />}
          {t("restart.new")}
        </button>
        <button
          onClick={() => navigate({ to: "/" })}
          className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-card py-4 text-base font-semibold text-foreground shadow-soft transition active:scale-[0.98]"
        >
          <Home className="size-5" />
          {t("restart.home")}
        </button>
      </div>
    </Screen>
  );
}

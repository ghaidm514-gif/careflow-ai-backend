import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Screen } from "@/components/Screen";
import { Logo } from "@/components/Logo";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CareFlow AI — AI-Powered Healthcare Guidance" },
      { name: "description", content: "CareFlow AI guides you to the right care with AI-powered symptom assessment. HIPAA-conscious, always available." },
      { property: "og:title", content: "CareFlow AI — AI-Powered Healthcare Guidance" },
      { property: "og:description", content: "AI-powered symptom assessment that guides you to the right care." },
      { property: "og:url", content: "https://flow-caretaker-ghiadm514.lovable.app/" },
    ],
    links: [{ rel: "canonical", href: "https://flow-caretaker-ghiadm514.lovable.app/" }],
  }),
  component: SplashPage,
});

function SplashPage() {
  const { t } = useI18n();
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => navigate({ to: "/language" }), 2200);
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <Screen>
      <div className="flex flex-1 flex-col items-center justify-center gap-8">
        <Logo size={120} />
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight">
            CareFlow <span className="text-primary">AI</span>
            <span className="sr-only"> — AI-Powered Healthcare Guidance</span>
          </h1>
          <p className="mt-4 text-base text-muted-foreground max-w-xs">
            {t("splash.tagline")}
          </p>
        </div>
      </div>
      <div className="flex justify-center gap-2 flex-wrap">
        <Chip icon="🔒">{t("splash.hipaa")}</Chip>
        <Chip icon="🤖">{t("splash.ai")}</Chip>
        <Chip icon="🏥">{t("splash.always")}</Chip>
      </div>
    </Screen>
  );
}

function Chip({ icon, children }: { icon: string; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-card px-4 py-2.5 text-xs font-semibold text-foreground shadow-soft">
      <span>{icon}</span>
      {children}
    </span>
  );
}

import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Loader2, MessageSquarePlus } from "lucide-react";
import { Screen, IconTile } from "@/components/Screen";
import { useI18n, type Lang } from "@/lib/i18n";
import { api, ApiError } from "@/lib/api";
import { sessionStore } from "@/lib/session";

export const Route = createFileRoute("/language")({
  head: () => ({
    meta: [
      { title: "Choose Language — CareFlow AI" },
      { name: "description", content: "Select English or Arabic to continue with CareFlow AI's symptom assessment." },
      { property: "og:title", content: "Choose Language — CareFlow AI" },
      { property: "og:description", content: "Select English or Arabic to continue." },
      { property: "og:url", content: "https://flow-caretaker-ghiadm514.lovable.app/language" },
    ],
    links: [{ rel: "canonical", href: "https://flow-caretaker-ghiadm514.lovable.app/language" }],
  }),
  component: LanguagePage,
});

function LanguagePage() {
  const { t, lang, setLang } = useI18n();
  const [selected, setSelected] = useState<Lang>(lang);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleContinue = async () => {
    setLang(selected);
    setBusy(true);
    setError(null);
    try {
      sessionStore.clearAll();
      const s = await api.createSession(selected);
      sessionStore.setSessionId(s.session_id);
      navigate({ to: "/disclaimer" });
    } catch (e) {
      setError(e instanceof ApiError ? e.message : t("err.offline"));
    } finally {
      setBusy(false);
    }
  };


  return (
    <Screen>
      <div className="mb-6">
        <IconTile tone="primary" size="lg">
          <MessageSquarePlus />
        </IconTile>
      </div>
      <h1 className="text-3xl font-extrabold tracking-tight">{t("lang.title")}</h1>
      <p className="mt-3 text-base text-muted-foreground">{t("lang.subtitle")}</p>

      <div className="mt-8 flex flex-col gap-4">
        <LangOption
          selected={selected === "ar"}
          onSelect={() => setSelected("ar")}
          flag="🇸🇦"
          title="العربية"
          desc={t("lang.ar.desc")}
          dir="rtl"
        />
        <LangOption
          selected={selected === "en"}
          onSelect={() => setSelected("en")}
          flag="🇬🇧"
          title="English"
          desc={t("lang.en.desc")}
          dir="ltr"
        />
      </div>

      <div className="flex-1" />
      {error && (
        <div className="mt-4 rounded-2xl bg-warning-soft px-4 py-2 text-xs font-semibold text-warning">
          {error}
        </div>
      )}
      <button
        onClick={handleContinue}
        disabled={busy}
        className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-semibold text-primary-foreground shadow-glow-primary transition active:scale-[0.98] disabled:opacity-60"
      >
        {busy && <Loader2 className="size-5 animate-spin" />}
        {t("lang.continue")}
      </button>

    </Screen>
  );
}

function LangOption({
  selected, onSelect, flag, title, desc, dir,
}: {
  selected: boolean; onSelect: () => void; flag: string; title: string; desc: string; dir: "ltr" | "rtl";
}) {
  return (
    <button
      onClick={onSelect}
      className={`flex items-center gap-4 rounded-3xl p-4 text-start transition ${
        selected
          ? "bg-primary-soft border-2 border-primary shadow-soft"
          : "bg-card border-2 border-transparent shadow-soft"
      }`}
    >
      <div className="flex size-14 items-center justify-center rounded-2xl bg-muted text-3xl">
        {flag}
      </div>
      <div className="flex-1" dir={dir}>
        <div className={`text-xl font-extrabold ${selected ? "text-primary" : "text-foreground"}`}>{title}</div>
        <div className={`mt-1 text-sm ${selected ? "text-primary/80" : "text-muted-foreground"}`}>{desc}</div>
      </div>
      <div
        className={`flex size-6 shrink-0 items-center justify-center rounded-full border-2 ${
          selected ? "border-primary bg-primary" : "border-border bg-transparent"
        }`}
      >
        {selected && <span className="size-2 rounded-full bg-white" />}
      </div>
    </button>
  );
}

import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  FileText,
  Stethoscope,
  HospitalIcon,
  MessageSquare,
  ShieldAlert,
  Sparkles,
  Clock,
  RotateCcw,
  CheckCircle2,
} from "lucide-react";
import { Screen, IconTile } from "@/components/Screen";
import { LoadingView, ErrorView } from "@/components/StatusView";
import { useI18n } from "@/lib/i18n";
import { api, ApiError, type TriageRequest } from "@/lib/api";
import { sessionStore } from "@/lib/session";

export const Route = createFileRoute("/summary")({
  head: () => ({
    meta: [
      { title: "Visit Summary — CareFlow AI" },
      { name: "description", content: "Review the AI-generated summary of your CareFlow AI symptom assessment and recommended next steps." },
      { property: "og:title", content: "Visit Summary — CareFlow AI" },
      { property: "og:description", content: "AI-generated summary of your symptom assessment and recommended next steps." },
      { property: "og:url", content: "https://flow-caretaker-ghiadm514.lovable.app/summary" },
    ],
    links: [{ rel: "canonical", href: "https://flow-caretaker-ghiadm514.lovable.app/summary" }],
  }),
  component: SummaryPage,
});

function SummaryPage() {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const [data, setData] = useState<TriageRequest | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const requestId = sessionStore.getRequestId();
      if (!requestId) {
        setError(t("err.noSession"));
        setLoading(false);
        return;
      }
      const req = await api.getTriageRequest(requestId);
      setData(req);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : t("err.offline"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (loading) {
    return (
      <Screen>
        <LoadingView label={t("status.preparing")} />
      </Screen>
    );
  }

  if (error || !data) {
    return (
      <Screen>
        <ErrorView
          title={t("err.title")}
          message={error ?? t("err.generic")}
          retryLabel={t("err.retry")}
          onRetry={() => void load()}
        />
      </Screen>
    );
  }

  const triage = data.triage_category || data.urgency_label || "";
  const destination = data.recommended_destination || data.service || "";
  const chiefComplaint = data.chief_complaint || sessionStore.getComplaint() || "";
  const answers = data.answers ?? [];
  const safetyRule = data.safety_rule || null;
  const aiSummary = data.ai_summary || data.reason || "";
  const timestamp = data.created_at
    ? new Intl.DateTimeFormat(lang === "ar" ? "ar-SA" : "en-US", {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(data.created_at))
    : new Intl.DateTimeFormat(lang === "ar" ? "ar-SA" : "en-US", {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date());

  return (
    <Screen>
      <h1 className="text-2xl font-extrabold">{t("sum.title")}</h1>
      <p className="mt-1 text-sm text-muted-foreground">{t("sum.subtitle")}</p>

      <div className="mt-4">
        <span className="inline-flex items-center gap-2 rounded-full bg-primary-soft px-4 py-2 text-sm font-bold text-primary">
          <CheckCircle2 className="size-4" />
          {t("sum.saved")}
        </span>
      </div>

      <div className="mt-6 grid gap-3">
        {triage && (
          <div className="rounded-3xl bg-warning-soft p-5">
            <div className="flex items-center gap-4">
              <IconTile tone="warning" size="lg"><Stethoscope /></IconTile>
              <div className="flex-1">
                <div className="text-xs font-extrabold tracking-widest" style={{ color: "oklch(0.42 0.14 45)" }}>
                  {t("sum.triageLabel")}
                </div>
                <div className="text-2xl font-extrabold" style={{ color: "oklch(0.35 0.12 40)" }}>
                  {triage}
                </div>
              </div>
            </div>
          </div>
        )}

        {destination && (
          <div
            className="rounded-3xl p-5 text-white shadow-soft"
            style={{ background: "linear-gradient(135deg, oklch(0.5 0.11 175) 0%, oklch(0.4 0.1 180) 100%)" }}
          >
            <div className="flex items-center gap-4">
              <div className="flex size-14 items-center justify-center rounded-2xl bg-white/15 backdrop-blur">
                <HospitalIcon className="size-6 text-white" />
              </div>
              <div className="flex-1">
                <div className="text-xs font-extrabold tracking-widest text-white/80">{t("sum.destLabel")}</div>
                <div className="text-xl font-extrabold leading-tight">{destination}</div>
              </div>
            </div>
          </div>
        )}
      </div>

      {chiefComplaint && (
        <Section icon={<FileText />} label={t("sum.complaint")}>
          <p className="text-base leading-relaxed text-foreground">{chiefComplaint}</p>
        </Section>
      )}

      {answers.length > 0 && (
        <Section icon={<MessageSquare />} label={t("sum.answers")}>
          <ul className="flex flex-col gap-3">
            {answers.map((ans, i) => (
              <li key={ans.question_id ?? i} className="rounded-2xl bg-card p-4 shadow-soft">
                <div className="text-xs font-semibold text-muted-foreground">{ans.question_text}</div>
                <div className="mt-1 text-sm font-semibold text-foreground">{ans.answer_text}</div>
              </li>
            ))}
          </ul>
        </Section>
      )}

      {safetyRule && (
        <Section icon={<ShieldAlert />} label={t("sum.safety")} tone="warning">
          <div className="rounded-2xl bg-warning-soft p-4 text-sm font-semibold" style={{ color: "oklch(0.4 0.12 45)" }}>
            {safetyRule}
          </div>
        </Section>
      )}

      {aiSummary && (
        <Section icon={<Sparkles />} label={t("sum.ai")}>
          <p className="text-base leading-relaxed text-foreground">{aiSummary}</p>
        </Section>
      )}

      <div className="mt-6 flex items-center gap-2 text-xs font-semibold text-muted-foreground">
        <Clock className="size-4" />
        {timestamp}
      </div>

      <div className="flex-1" />
      <button
        onClick={() => navigate({ to: "/restart" })}
        className="mt-8 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-semibold text-primary-foreground shadow-glow-primary transition active:scale-[0.98]"
      >
        <RotateCcw className="size-5" />
        {t("reco.restart")}
      </button>
    </Screen>
  );
}

function Section({
  icon,
  label,
  children,
  tone = "primary",
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
  tone?: "primary" | "warning";
}) {
  return (
    <div className="mt-6 flex items-start gap-4">
      <IconTile tone={tone} size="md">{icon}</IconTile>
      <div className="flex-1">
        <div className="text-xs font-extrabold tracking-widest text-muted-foreground">{label}</div>
        <div className="mt-2">{children}</div>
      </div>
    </div>
  );
}

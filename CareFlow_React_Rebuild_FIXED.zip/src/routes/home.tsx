import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Bell, Mic, ShieldCheck, Zap, Hospital, Calendar, Pill, FileText, Loader2 } from "lucide-react";
import { Screen, IconTile } from "@/components/Screen";
import { useI18n } from "@/lib/i18n";
import { api, ApiError, isTerminalStatus } from "@/lib/api";
import { sessionStore } from "@/lib/session";

export const Route = createFileRoute("/home")({
  head: () => ({
    meta: [
      { title: "Symptom Checker — CareFlow AI" },
      { name: "description", content: "Describe your symptoms to receive AI-guided healthcare recommendations from CareFlow AI." },
      { property: "og:title", content: "Symptom Checker — CareFlow AI" },
      { property: "og:description", content: "Describe your symptoms to receive AI-guided healthcare recommendations." },
      { property: "og:url", content: "https://flow-caretaker-ghiadm514.lovable.app/home" },
    ],
    links: [{ rel: "canonical", href: "https://flow-caretaker-ghiadm514.lovable.app/home" }],
  }),
  component: HomePage,
});

function HomePage() {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const start = async () => {
    if (!text.trim()) {
      setError(t("home.empty"));
      return;
    }
    setError(null);
    setLoading(true);
    try {
      let sessionId = sessionStore.getSessionId();
      if (!sessionId) {
        const s = await api.createSession(lang);
        sessionId = s.session_id;
        sessionStore.setSessionId(sessionId);
      }
      const req = await api.createTriageRequest(sessionId!, text.trim());

      sessionStore.setRequestId(req.request_id);
      sessionStore.setComplaint(text.trim());
      if (isTerminalStatus(req.status)) {
        navigate({ to: "/recommendation" });
      } else {
        navigate({ to: "/chat" });
      }
    } catch (e) {
      setError(e instanceof ApiError ? e.message : t("err.offline"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Screen>
      <h1 className="sr-only">Your AI Health Assistant</h1>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-4xl font-extrabold tracking-tight" aria-hidden="true">
            {t("home.hello")} <span>👋</span>
          </p>
          <p className="mt-2 text-base text-muted-foreground">{t("home.subtitle")}</p>
        </div>
        <button
          type="button"
          aria-label={t("home.notifications")}
          className="relative inline-flex size-11 items-center justify-center rounded-2xl bg-card shadow-soft"
        >
          <Bell className="size-5" />
          <span className="absolute top-2 end-2 size-2 rounded-full bg-danger" />
        </button>
      </div>

      <div className="mt-6 rounded-3xl bg-card p-5 shadow-soft">
        <div className="flex items-center gap-3">
          <IconTile tone="primary" size="md"><ShieldCheck /></IconTile>
          <div className="flex-1">
            <div className="font-extrabold">{t("home.assistant")}</div>
            <div className="mt-0.5 flex items-center gap-1.5 text-xs font-semibold text-primary">
              <span className="size-1.5 rounded-full bg-primary" />
              {t("home.ready")}
            </div>
          </div>
          <button
            type="button"
            aria-label={t("home.voiceInput")}
            className="inline-flex size-11 items-center justify-center rounded-2xl bg-primary text-primary-foreground"
          >
            <Mic className="size-5" />
          </button>
        </div>
        <div className="my-4 h-px bg-border" />
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={t("home.placeholder")}
          rows={3}
          className="w-full resize-none bg-transparent text-base placeholder:text-muted-foreground focus:outline-none"
        />
        <div className="mt-3 flex items-center justify-between gap-3">
          <span className="text-xs text-muted-foreground">{t("home.hint")}</span>
          <button
            onClick={start}
            disabled={loading}
            className="inline-flex items-center gap-2 rounded-2xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-glow-primary transition active:scale-[0.98] disabled:opacity-60"
          >
            {loading ? <Loader2 className="size-4 animate-spin" /> : <Zap className="size-4" />}
            {t("home.start")}
          </button>
        </div>
        {error && (
          <div className="mt-3 rounded-2xl bg-warning-soft px-4 py-2 text-xs font-semibold text-warning">
            {error}
          </div>
        )}
      </div>

      <div className="mt-8 flex items-end justify-between">
        <h2 className="text-xl font-extrabold">{t("home.quick")}</h2>
        <button className="text-sm font-semibold text-primary">{t("home.seeall")}</button>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <QuickCard icon={<Hospital />} tone="primary" title={t("home.q.symptoms")} desc={t("home.q.symptoms.desc")} onClick={() => navigate({ to: "/chat" })} />
        <QuickCard icon={<Calendar />} tone="info" title={t("home.q.appointment")} desc={t("home.q.appointment.desc")} />
        <QuickCard icon={<Pill />} tone="danger" title="Meds" desc="Refills & info" />
        <QuickCard icon={<FileText />} tone="warning" title="Records" desc="View history" />
      </div>
    </Screen>
  );
}

function QuickCard({ icon, tone, title, desc, onClick }: { icon: React.ReactNode; tone: "primary" | "info" | "danger" | "warning"; title: string; desc: string; onClick?: () => void }) {
  return (
    <button onClick={onClick} className="flex flex-col items-start gap-3 rounded-3xl bg-card p-4 text-start shadow-soft transition active:scale-[0.98]">
      <IconTile tone={tone} size="md">{icon}</IconTile>
      <div>
        <div className="font-extrabold">{title}</div>
        <div className="mt-0.5 text-xs text-muted-foreground">{desc}</div>
      </div>
    </button>
  );
}

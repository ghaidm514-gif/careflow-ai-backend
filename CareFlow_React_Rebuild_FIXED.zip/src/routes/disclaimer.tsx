import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, ShieldCheck, Clock, FileX, Pill } from "lucide-react";
import { Screen, IconTile } from "@/components/Screen";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/disclaimer")({
  head: () => ({
    meta: [
      { title: "Medical Disclaimer — CareFlow AI" },
      { name: "description", content: "Important safety and usage information before starting your CareFlow AI symptom assessment." },
      { property: "og:title", content: "Medical Disclaimer — CareFlow AI" },
      { property: "og:description", content: "Important safety and usage information before starting your assessment." },
      { property: "og:url", content: "https://flow-caretaker-ghiadm514.lovable.app/disclaimer" },
    ],
    links: [{ rel: "canonical", href: "https://flow-caretaker-ghiadm514.lovable.app/disclaimer" }],
  }),
  component: DisclaimerPage,
});

function DisclaimerPage() {
  const { t, dir } = useI18n();
  const navigate = useNavigate();
  const BackIcon = dir === "rtl" ? ChevronRight : ChevronLeft;

  return (
    <Screen>
      <button
        onClick={() => navigate({ to: "/language" })}
        className="inline-flex size-10 items-center justify-center rounded-2xl bg-card shadow-soft"
        aria-label={t("back")}
      >
        <BackIcon className="size-5" />
      </button>

      <div className="mt-8">
        <IconTile tone="primary" size="lg">
          <ShieldCheck />
        </IconTile>
      </div>

      <h1 className="mt-6 text-4xl font-extrabold tracking-tight">{t("disc.title")}</h1>
      <p className="mt-3 text-base text-muted-foreground">{t("disc.subtitle")}</p>

      <div className="mt-6 flex flex-col divide-y divide-border rounded-3xl bg-card p-2 shadow-soft">
        <Item tone="primary" icon={<Clock />} title={t("disc.item1.title")} desc={t("disc.item1.desc")} />
        <Item tone="danger" icon={<FileX />} title={t("disc.item2.title")} desc={t("disc.item2.desc")} />
        <Item tone="danger" icon={<Pill />} title={t("disc.item3.title")} desc={t("disc.item3.desc")} />
      </div>

      <div className="flex-1" />
      <button
        onClick={() => navigate({ to: "/home" })}
        className="mt-8 w-full rounded-2xl bg-primary py-4 text-base font-semibold text-primary-foreground shadow-glow-primary transition active:scale-[0.98]"
      >
        {t("disc.accept")}
      </button>
    </Screen>
  );
}

function Item({ tone, icon, title, desc }: { tone: "primary" | "danger"; icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-4 p-4">
      <IconTile tone={tone} size="md">{icon}</IconTile>
      <div className="flex-1 pt-0.5">
        <div className="flex items-start gap-2 font-extrabold text-foreground">
          <span className="text-primary">✓</span>
          <span>{title}</span>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{desc}</p>
      </div>
    </div>
  );
}

import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { Screen, IconTile } from "@/components/Screen";
import { LoadingView, ErrorView } from "@/components/StatusView";
import { useI18n } from "@/lib/i18n";
import { api, ApiError, isTerminalStatus, type BackendQuestion, type TriageRequest } from "@/lib/api";
import { sessionStore } from "@/lib/session";

export const Route = createFileRoute("/chat")({
  head: () => ({
    meta: [
      { title: "AI Symptom Assessment — CareFlow AI" },
      { name: "description", content: "Answer a few AI-guided questions about your symptoms to get a personalized care recommendation." },
      { property: "og:title", content: "AI Symptom Assessment — CareFlow AI" },
      { property: "og:description", content: "Answer AI-guided questions to get a personalized care recommendation." },
      { property: "og:url", content: "https://flow-caretaker-ghiadm514.lovable.app/chat" },
    ],
    links: [{ rel: "canonical", href: "https://flow-caretaker-ghiadm514.lovable.app/chat" }],
  }),
  component: ChatPage,
});

function ChatPage() {
  const { t, dir } = useI18n();
  const navigate = useNavigate();
  const BackIcon = dir === "rtl" ? ChevronRight : ChevronLeft;

  const [question, setQuestion] = useState<BackendQuestion | null>(null);
  const [step, setStep] = useState(1);
  const [totalHint, setTotalHint] = useState<number | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const applyRequest = (req: TriageRequest) => {
    if (isTerminalStatus(req?.status)) {
      navigate({ to: "/recommendation" });
      return;
    }
    if (req?.next_question) {
      setQuestion(req.next_question);
      setSelected(null);
      const answered = Array.isArray(req.answers) ? req.answers.length : 0;
      setStep(answered + 1);
      if (typeof (req as { total_questions?: number }).total_questions === "number") {
        setTotalHint((req as { total_questions?: number }).total_questions ?? null);
      }
    } else {
      // in_triage but no question yet — wait/retry
      setQuestion(null);
    }
  };

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const requestId = sessionStore.getRequestId();
      if (!requestId) {
        setError(t("err.noSession"));
        setLoading(false);
        return;
      }
      const req = await api.getTriageRequest(requestId);
      applyRequest(req);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : t("err.offline"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleNext = async () => {
    if (!selected || !question) return;
    setSubmitting(true);

    setError(null);
    try {
      const requestId = sessionStore.getRequestId()!;
      const answerText =
        question.options?.find((o) => o.id === selected)?.label ?? selected;
      const updated = await api.submitAnswer(requestId, {
        question_id: question.id ?? "",
        answer: answerText ?? "",
      });

      applyRequest(updated);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : t("err.offline"));
    } finally {
      setSubmitting(false);
    }
  };

  const goBack = () => navigate({ to: "/home" });

  const total = totalHint ?? Math.max(step, 6);
  const pct = Math.min(100, (step / total) * 100);

  return (
    <Screen>
      <h1 className="sr-only">AI Symptom Assessment</h1>
      <div className="grid grid-cols-[auto_1fr_auto] items-center gap-3">
        <button
          type="button"
          onClick={goBack}
          aria-label={t("back")}
          className="inline-flex size-10 items-center justify-center rounded-2xl bg-card shadow-soft"
        >
          <BackIcon className="size-5" />
        </button>
        <div className="flex flex-col items-center gap-2">
          <span className="rounded-full bg-primary-soft px-4 py-1.5 text-xs font-extrabold tracking-widest text-primary">
            {question?.category ? t(question.category) : t("chat.duration")}
          </span>
          <span className="text-sm text-muted-foreground">
            {t("chat.q")} <b className="text-foreground">{step}</b> {t("chat.of")} {total}
          </span>
        </div>
        <div className="size-10" />
      </div>

      <div className="mt-6 h-1.5 w-full overflow-hidden rounded-full bg-muted">
        <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${pct}%` }} />
      </div>

      {loading ? (
        <LoadingView label={t("status.loading")} />
      ) : error ? (
        <ErrorView
          title={t("err.title")}
          message={error}
          retryLabel={t("err.retry")}
          onRetry={() => void load()}
        />
      ) : question ? (
        <>
          <div className="mt-8 rounded-3xl bg-card p-5 shadow-soft">
            <div className="flex items-start gap-3">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-primary font-extrabold text-primary-foreground">
                {step}
              </div>
              <h2 className="pt-1 text-xl font-extrabold leading-snug">{question.text}</h2>
            </div>
          </div>

          {(Array.isArray(question.options) ? question.options.length : 0) > 0 ? (
            <div className="mt-5 flex flex-col gap-3">
              {(Array.isArray(question.options) ? question.options : []).map((o) => (
                <button
                  key={o.id}
                  onClick={() => setSelected(o.id)}
                  className={`flex items-center gap-4 rounded-3xl bg-card p-4 text-start shadow-soft transition ${
                    selected === o.id ? "ring-2 ring-primary" : ""
                  }`}
                >
                  <IconTile tone="muted" size="md">
                    <span className="text-lg font-extrabold text-primary">
                      {(o.label ?? "").charAt(0).toUpperCase()}
                    </span>
                  </IconTile>
                  <div className="flex-1">
                    <div className="font-extrabold">{o.label ?? ""}</div>
                    {o.description && (
                      <div className="mt-0.5 text-sm text-muted-foreground">{o.description}</div>
                    )}
                  </div>
                  <div
                    className={`flex size-6 shrink-0 items-center justify-center rounded-full border-2 ${
                      selected === o.id ? "border-primary bg-primary" : "border-border"
                    }`}
                  >
                    {selected === o.id && <span className="size-2 rounded-full bg-white" />}
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="mt-5 flex flex-col gap-3">
              <div className="grid grid-cols-3 gap-3">
                {["yes", "no", "not sure"].map((v) => (
                  <button
                    key={v}
                    onClick={() => setSelected(v)}
                    className={`rounded-2xl bg-card px-4 py-3 text-sm font-extrabold capitalize shadow-soft transition ${
                      selected === v ? "ring-2 ring-primary text-primary" : "text-foreground"
                    }`}
                  >
                    {v}
                  </button>
                ))}
              </div>
              <textarea
                value={selected && !["yes", "no", "not sure"].includes(selected) ? selected : ""}
                onChange={(e) => setSelected(e.target.value)}
                placeholder={t("home.placeholder")}
                rows={3}
                className="w-full resize-none rounded-3xl bg-card p-4 text-base shadow-soft placeholder:text-muted-foreground focus:outline-none"
              />
            </div>
          )}

          <div className="flex-1" />
          <button
            onClick={handleNext}
            disabled={!selected || submitting}
            className="mt-8 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-semibold text-primary-foreground shadow-glow-primary transition active:scale-[0.98] disabled:opacity-40 disabled:shadow-none"
          >
            {submitting && <Loader2 className="size-5 animate-spin" />}
            {t("chat.next")}
          </button>
        </>
      ) : null}
    </Screen>
  );
}

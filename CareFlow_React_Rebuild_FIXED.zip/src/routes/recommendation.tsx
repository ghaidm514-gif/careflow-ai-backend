import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CheckCircle2, AlertTriangle, HospitalIcon, Star, CheckSquare } from "lucide-react";
import { Screen, IconTile } from "@/components/Screen";
import { LoadingView, ErrorView } from "@/components/StatusView";
import { useI18n } from "@/lib/i18n";
import { api, ApiError, isTerminalStatus, type TriageRequest } from "@/lib/api";
import { sessionStore } from "@/lib/session";

export const Route = createFileRoute("/recommendation")({
  head: () => ({
    meta: [
      { title: "Your Care Recommendation — CareFlow AI" },
      { name: "description", content: "Your personalized AI-guided care recommendation based on the symptoms you shared." },
      { property: "og:title", content: "Your Care Recommendation — CareFlow AI" },
      { property: "og:description", content: "Personalized AI-guided care recommendation based on your symptoms." },
      { property: "og:url", content: "https://flow-caretaker-ghiadm514.lovable.app/recommendation" },
    ],
    links: [{ rel: "canonical", href: "https://flow-caretaker-ghiadm514.lovable.app/recommendation" }],
  }),
  component: RecommendationPage,
});

function RecommendationPage() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [data, setData] = useState<TriageRequest | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const requestId = sessionStore.getRequestId();
      if (!requestId) {
        setError(t("err.noSession"));
        setLoading(false);
        return;
      }
      const req = await api.getTriageRequest(requestId);
      if (!isTerminalStatus(req.status)) {
        navigate({ to: "/chat" });
        return;
      }
      setData(req);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : t("err.offline"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (loading) {
    return (
      <Screen>
        <LoadingView label={t("status.analyzing")} />
      </Screen>
    );
  }

  if (error || !data) {
    return (
      <Screen>
        <ErrorView
          title={t("err.title")}
          message={error ?? t("err.generic")}
          retryLabel={t("err.retry")}
          onRetry={() => void load()}
        />
      </Screen>
    );
  }

  const urgencyLabel = data.urgency_label || data.triage_category || "";
  const action = data.action || data.recommended_destination || "";
  const service = data.service || data.recommended_destination || "";
  const rating = data.rating ?? 4;
  const wait = data.wait || "";
  const reason = data.reason || data.ai_summary || "";

  return (
    <Screen>
      <h1 className="text-2xl font-extrabold">{t("reco.title")}</h1>

      <div className="mt-4">
        <span className="inline-flex items-center gap-2 rounded-full bg-primary-soft px-4 py-2 text-sm font-bold text-primary">
          <CheckCircle2 className="size-4" />
          {t("reco.complete")}
        </span>
      </div>

      <div className="mt-6 rounded-3xl bg-warning-soft p-5">
        <div className="flex items-center gap-4">
          <IconTile tone="warning" size="lg"><AlertTriangle /></IconTile>
          <div className="flex-1">
            <div className="text-xs font-extrabold tracking-widest" style={{ color: "oklch(0.42 0.14 45)" }}>
              {t("reco.urgency")}
            </div>
            <div className="text-3xl font-extrabold" style={{ color: "oklch(0.35 0.12 40)" }}>
              {urgencyLabel}
            </div>
          </div>
          {action && (
            <div className="flex size-20 shrink-0 items-center justify-center rounded-full bg-warning p-2 text-center text-[10px] font-bold leading-tight text-white">
              {action}
            </div>
          )}
        </div>
        {action && (
          <div className="mt-4 flex items-center gap-2 rounded-2xl bg-card px-4 py-3 text-sm font-semibold" style={{ color: "oklch(0.4 0.12 45)" }}>
            <span className="size-2 rounded-full bg-warning" />
            {action}
          </div>
        )}
      </div>

      <div
        className="mt-4 rounded-3xl p-5 text-white shadow-soft"
        style={{ background: "linear-gradient(135deg, oklch(0.5 0.11 175) 0%, oklch(0.4 0.1 180) 100%)" }}
      >
        <div className="flex items-center gap-4">
          <div className="flex size-14 items-center justify-center rounded-2xl bg-white/15 backdrop-blur">
            <HospitalIcon className="size-6 text-white" />
          </div>
          <div className="flex-1">
            <div className="text-xs font-extrabold tracking-widest text-white/80">{t("reco.service")}</div>
            <div className="text-2xl font-extrabold leading-tight">{service}</div>
          </div>
        </div>
        <div className="mt-4 flex items-center gap-2 text-sm">
          <div className="flex gap-0.5">
            {[1, 2, 3, 4, 5].map((i) => (
              <Star key={i} className={`size-4 ${i <= Math.round(rating) ? "fill-white text-white" : "text-white/40"}`} />
            ))}
          </div>
          <span className="font-semibold">{rating.toFixed(1)}</span>
          {wait && <span className="text-white/60">·</span>}
          {wait && <span className="text-white/90">{wait}</span>}
        </div>
      </div>

      {reason && (
        <div className="mt-6 flex items-start gap-4">
          <IconTile tone="primary" size="md"><CheckSquare /></IconTile>
          <div className="flex-1">
            <div className="text-xs font-extrabold tracking-widest text-muted-foreground">{t("reco.reason")}</div>
            <p className="mt-2 text-base leading-relaxed text-foreground">{reason}</p>
          </div>
        </div>
      )}

      <div className="flex-1" />
      <div className="mt-8 flex flex-col gap-3">
        <button
          onClick={() => navigate({ to: "/summary" })}
          className="w-full rounded-2xl bg-primary py-4 text-base font-semibold text-primary-foreground shadow-glow-primary transition active:scale-[0.98]"
        >
          {t("reco.viewSummary")}
        </button>
        <button
          onClick={() => navigate({ to: "/restart" })}
          className="w-full rounded-2xl bg-card py-4 text-base font-semibold text-foreground shadow-soft transition active:scale-[0.98]"
        >
          {t("reco.restart")}
        </button>
      </div>
    </Screen>
  );
}

import type { ReactNode } from "react";

export function Screen({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className="min-h-screen bg-background">
      <main className={`mx-auto flex min-h-screen w-full max-w-md flex-col px-6 pt-8 pb-10 ${className}`}>
        {children}
      </main>
    </div>
  );
}

export function IconTile({
  children,
  tone = "primary",
  size = "md",
  className = "",
}: {
  children: ReactNode;
  tone?: "primary" | "warning" | "info" | "danger" | "muted" | "primary-dark";
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const tones: Record<string, string> = {
    primary: "bg-primary-soft text-primary",
    "primary-dark": "bg-primary text-primary-foreground",
    warning: "bg-warning text-white",
    info: "bg-info-soft text-info",
    danger: "bg-danger-soft text-danger",
    muted: "bg-muted text-muted-foreground",
  };
  const sizes: Record<string, string> = {
    sm: "size-10 rounded-xl [&>svg]:size-5",
    md: "size-12 rounded-2xl [&>svg]:size-6",
    lg: "size-16 rounded-2xl [&>svg]:size-7",
  };
  return (
    <div className={`inline-flex items-center justify-center ${sizes[size]} ${tones[tone]} ${className}`}>
      {children}
    </div>
  );
}

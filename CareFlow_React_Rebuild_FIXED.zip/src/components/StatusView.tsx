import { Loader2, AlertTriangle, RotateCcw } from "lucide-react";

export function LoadingView({ label }: { label: string }) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-3 py-12 text-center">
      <Loader2 className="size-8 animate-spin text-primary" />
      <p className="text-sm font-semibold text-muted-foreground">{label}</p>
    </div>
  );
}

export function ErrorView({
  title,
  message,
  retryLabel,
  onRetry,
}: {
  title: string;
  message: string;
  retryLabel: string;
  onRetry: () => void;
}) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4 py-12 text-center">
      <div className="flex size-16 items-center justify-center rounded-3xl bg-warning-soft">
        <AlertTriangle className="size-8 text-warning" />
      </div>
      <div>
        <h2 className="text-lg font-extrabold text-foreground">{title}</h2>
        <p className="mt-2 max-w-xs text-sm text-muted-foreground">{message}</p>
      </div>
      <button
        onClick={onRetry}
        className="inline-flex items-center gap-2 rounded-2xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-glow-primary transition active:scale-[0.98]"
      >
        <RotateCcw className="size-4" />
        {retryLabel}
      </button>
    </div>
  );
}

export function Logo({ size = 96, glow = true }: { size?: number; glow?: boolean }) {
  return (
    <div
      className={`relative inline-flex items-center justify-center rounded-[28%] ${glow ? "shadow-glow-primary" : ""}`}
      style={{
        width: size,
        height: size,
        background: "linear-gradient(160deg, oklch(0.6 0.13 175) 0%, oklch(0.4 0.1 180) 100%)",
      }}
    >
      <svg viewBox="0 0 24 24" fill="none" style={{ width: size * 0.5, height: size * 0.5 }}>
        <path d="M12 5v14M5 12h14" stroke="white" strokeWidth="3" strokeLinecap="round" />
      </svg>
      <span
        className="absolute rounded-full bg-info"
        style={{
          width: size * 0.14,
          height: size * 0.14,
          top: size * 0.22,
          right: size * 0.22,
          boxShadow: "0 0 0 3px white",
        }}
      />
    </div>
  );
}

// Session/request storage. Uses sessionStorage so IDs are scoped to the tab
// and cleared when the browser is closed.
const SESSION_KEY = "careflow.session_id";
const REQUEST_KEY = "careflow.request_id";
const COMPLAINT_KEY = "careflow.complaint";

const store = (): Storage | null =>
  typeof window !== "undefined" ? window.sessionStorage : null;

export const sessionStore = {
  getSessionId: () => store()?.getItem(SESSION_KEY) ?? null,
  setSessionId: (id: string) => store()?.setItem(SESSION_KEY, id),

  getRequestId: () => store()?.getItem(REQUEST_KEY) ?? null,
  setRequestId: (id: string) => store()?.setItem(REQUEST_KEY, id),
  clearRequestId: () => store()?.removeItem(REQUEST_KEY),

  getComplaint: () => store()?.getItem(COMPLAINT_KEY) ?? null,
  setComplaint: (v: string) => store()?.setItem(COMPLAINT_KEY, v),

  clearAll: () => {
    const s = store();
    if (!s) return;
    s.removeItem(SESSION_KEY);
    s.removeItem(REQUEST_KEY);
    s.removeItem(COMPLAINT_KEY);
  },
};

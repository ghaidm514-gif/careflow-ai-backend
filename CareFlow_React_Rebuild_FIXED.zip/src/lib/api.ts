// FastAPI backend integration.
// Base URL is configured via VITE_API_URL (preferred) or VITE_API_BASE_URL (legacy).
const DEFAULT_FASTAPI_BASE = "http://localhost:8000";
const BASE =
  (
    (import.meta.env.VITE_API_URL as string | undefined) ||
    (import.meta.env.VITE_API_BASE_URL as string | undefined) ||
    DEFAULT_FASTAPI_BASE
  ).replace(/\/+$/, "");
const PREFIX = "/api/v1";

if (
  !import.meta.env.VITE_API_URL &&
  !import.meta.env.VITE_API_BASE_URL &&
  typeof window !== "undefined"
) {
  // eslint-disable-next-line no-console
  console.warn(
    `[api] VITE_API_URL is not set — using default FastAPI backend ${DEFAULT_FASTAPI_BASE}.`,
  );
}


export type TriageStatus =
  | "in_triage"
  | "recommendation_ready"
  | "safety_alert"
  | string;

export const isTerminalStatus = (s?: string) =>
  s === "recommendation_ready" || s === "triage_completed" || s === "safety_alert";

export interface BackendOption {
  id: string;
  label: string;
  description?: string;
  icon?: string;
}

export interface BackendQuestion {
  id: string;
  category?: string;
  text: string;
  options: BackendOption[];
}

export interface TriageMessage {
  role: "user" | "assistant";
  content: string;
  message_type: string;
  created_at: string;
}

export interface TriageAnswerRecord {
  question_id: string;
  question_text?: string;
  answer_id?: string;
  answer_text?: string;
  answer?: string;
}

export interface TriageRequest {
  request_id: string;
  session_id: string;
  status: TriageStatus;
  classification?: string;
  language?: string;
  initial_description?: string;
  chief_complaint?: string;
  messages?: TriageMessage[];
  next_question?: BackendQuestion | null;
  answers?: TriageAnswerRecord[];
  safety_flags?: unknown[];
  recommendation?: Record<string, unknown> | null;
  triage_category?: string;
  recommended_service?: string;
  recommended_destination?: string;
  urgency_level?: string;
  urgency_label?: string;
  action?: string;
  service?: string;
  wait?: string;
  rating?: number;
  reason?: string;
  safety_rule?: string | null;
  ai_summary?: string;
  created_at?: string;
  updated_at?: string;
}

function normalizeTriage(raw: TriageRequest | null | undefined): TriageRequest {
  const r: TriageRequest = { ...(raw ?? ({} as TriageRequest)) };
  if (!r.chief_complaint && r.initial_description) {
    r.chief_complaint = r.initial_description;
  }
  if (!r.recommended_destination && r.recommended_service) {
    r.recommended_destination = r.recommended_service;
  }
  r.messages = Array.isArray(r.messages) ? r.messages : [];
  r.answers = Array.isArray(r.answers) ? r.answers : [];
  r.safety_flags = Array.isArray(r.safety_flags) ? r.safety_flags : [];
  const messages = Array.isArray(r.messages) ? r.messages : [];
  r.messages = messages;
  if (!r.next_question && messages.length > 0) {
    const lastQ = [...messages]
      .reverse()
      .find((m) => m.message_type === "triage_question" && m.role === "assistant");
    if (lastQ) {
      r.next_question = {
        id: lastQ.created_at || `q_${messages.indexOf(lastQ)}`,
        text: lastQ.content ?? "",
        options: [],
      };
    }
  }
  if (r.next_question) {
    r.next_question = {
      ...r.next_question,
      id: r.next_question.id ?? "",
      text: r.next_question.text ?? "",
      options: Array.isArray(r.next_question.options) ? r.next_question.options : [],
    };
  }
  // pull recommendation fields up if backend nests them
  if (r.recommendation && typeof r.recommendation === "object") {
    const rec = r.recommendation as Record<string, unknown>;
    r.triage_category = r.triage_category ?? (rec.triage_category as string | undefined);
    r.recommended_destination =
      r.recommended_destination ??
      (rec.recommended_destination as string | undefined) ??
      (rec.recommended_service as string | undefined);
    r.urgency_level = r.urgency_level ?? (rec.urgency_level as string | undefined);
    r.urgency_label = r.urgency_label ?? (rec.urgency_label as string | undefined);
    r.action = r.action ?? (rec.action as string | undefined);
    r.service = r.service ?? (rec.service as string | undefined);
    r.wait = r.wait ?? (rec.wait as string | undefined);
    r.rating = r.rating ?? (rec.rating as number | undefined);
    r.reason = r.reason ?? (rec.reason as string | undefined);
    r.ai_summary = r.ai_summary ?? (rec.ai_summary as string | undefined);
    r.safety_rule = r.safety_rule ?? (rec.safety_rule as string | null | undefined);
  }
  return r;
}

export interface Session {
  session_id: string;
  created_at?: string;
}

export class ApiError extends Error {
  status?: number;
  constructor(message: string, status?: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${BASE}${PREFIX}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        ...(init.headers || {}),
      },
    });
  } catch (e) {
    throw new ApiError(
      e instanceof Error
        ? `Backend unavailable at ${BASE}. Please make sure the FastAPI server is running and CORS allows this frontend.`
        : "Backend unavailable. Please try again.",
    );
  }
  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body?.detail) msg = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
      else if (body?.message) msg = body.message;
    } catch {
      /* ignore */
    }
    if (res.status === 404) msg = `Not found: ${msg}`;
    else if (res.status === 409) msg = `Conflict: ${msg}`;
    throw new ApiError(msg, res.status);
  }

  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

export const api = {
  createSession: (lang: string) =>
    request<Session>("/sessions", {
      method: "POST",
      body: JSON.stringify({ language: lang }),
    }),

  createTriageRequest: async (sessionId: string, description: string) =>
    normalizeTriage(
      await request<TriageRequest>("/triage/requests", {
        method: "POST",
        body: JSON.stringify({ session_id: sessionId, description }),
      }),
    ),

  submitAnswer: async (
    requestId: string,
    payload: { question_id: string; answer: string },
  ) =>
    normalizeTriage(
      await request<TriageRequest>(`/triage/requests/${requestId}/answers`, {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    ),

  getTriageRequest: async (requestId: string) =>
    normalizeTriage(await request<TriageRequest>(`/triage/requests/${requestId}`)),
};


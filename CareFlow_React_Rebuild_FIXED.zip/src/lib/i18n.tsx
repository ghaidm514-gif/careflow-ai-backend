import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "en" | "ar";

type Dict = Record<string, string>;

const en: Dict = {
  "splash.tagline": "Navigate to the right care, with AI guidance.",
  "splash.hipaa": "HIPAA Secure",
  "splash.ai": "AI-Powered",
  "splash.always": "24 / 7",
  "lang.title": "Choose your language",
  "lang.subtitle": "Select your preferred language to continue. You can change this later in Settings.",
  "lang.ar.desc": "Default language for users in Saudi Arabia",
  "lang.en.desc": "Recommended for international users",
  "lang.continue": "Continue",
  "disc.title": "Before we begin",
  "disc.subtitle": "Please read the following important information.",
  "disc.item1.title": "Healthcare navigation and guidance",
  "disc.item1.desc": "CareFlow AI helps you identify the right service and guides you to the most appropriate care pathway.",
  "disc.item2.title": "No disease diagnosis",
  "disc.item2.desc": "The application does not diagnose medical conditions or interpret clinical test results.",
  "disc.item3.title": "No medication prescriptions",
  "disc.item3.desc": "The application does not prescribe, recommend, or substitute any medication or treatment plan.",
  "disc.accept": "I understand, continue",
  "home.hello": "Hello",
  "home.subtitle": "How can we help you today?",
  "home.notifications": "Notifications",
  "home.voiceInput": "Start voice input",
  "home.assistant": "AI Health Assistant",
  "home.ready": "Ready · Secure session",
  "home.placeholder": "Describe your question...",
  "home.hint": "Type or use voice input",
  "home.start": "Start AI Assessment",
  "home.quick": "Quick Actions",
  "home.seeall": "See all",
  "home.q.symptoms": "Symptoms",
  "home.q.symptoms.desc": "Describe how you feel",
  "home.q.appointment": "Appointment",
  "home.q.appointment.desc": "Schedule or manage",
  "chat.duration": "DURATION",
  "chat.q": "Question",
  "chat.of": "of",
  "chat.q1": "How long have you been experiencing these symptoms?",
  "chat.a1": "Less than 24 hours",
  "chat.a1.desc": "Started recently",
  "chat.a2": "1 – 3 days",
  "chat.a2.desc": "Past few days",
  "chat.a3": "4 – 7 days",
  "chat.a3.desc": "About a week",
  "chat.a4": "More than a week",
  "chat.a4.desc": "Ongoing or recurring",
  "chat.next": "Next",
  "reco.title": "AI Recommendation",
  "reco.complete": "AI analysis complete",
  "reco.urgency": "URGENCY LEVEL",
  "reco.moderate": "Moderate",
  "reco.doctor24": "See a doctor within 24 hours",
  "reco.service": "RECOMMENDED SERVICE",
  "reco.urgent": "Urgent Care Center",
  "reco.wait": "18–40 min wait",
  "reco.reason": "REASON",
  "reco.reasonText": "Your reported symptoms — productive cough, low-grade fever, and chest tightness for 3 days — are consistent with a respiratory infection requiring clinical evaluation and possible antibiotic therapy.",
  "reco.restart": "Start a new session",
  "reco.viewSummary": "View visit summary",
  "sum.title": "Visit Summary",
  "sum.subtitle": "A record of your session and AI-guided recommendation.",
  "sum.saved": "Summary saved securely",
  "sum.triageLabel": "TRIAGE CATEGORY",
  "sum.triage.moderate": "Moderate — within 24 hours",
  "sum.destLabel": "RECOMMENDED DESTINATION",
  "sum.complaint": "CHIEF COMPLAINT",
  "sum.complaintText": "Productive cough with low-grade fever and chest tightness for the last 3 days.",
  "sum.answers": "YOUR ANSWERS",
  "sum.q2": "Do you have a fever?",
  "sum.a2": "Yes, low-grade (37.8°C)",
  "sum.q3": "Any shortness of breath?",
  "sum.a3": "Mild, only when active",
  "sum.safety": "SAFETY RULE TRIGGERED",
  "sum.safetyText": "Chest tightness reported — escalated to same-day clinical evaluation.",
  "sum.ai": "AI SUMMARY",
  "sum.aiText": "Symptoms suggest a respiratory infection of moderate severity. In-person evaluation within 24 hours is recommended to rule out pneumonia and consider antibiotic therapy.",
  "restart.title": "Session complete",
  "restart.subtitle": "Thank you for using CareFlow AI. Your session summary has been saved.",
  "restart.new": "Start new session",
  "restart.home": "Back to home",
  "back": "Back",
  "skip": "Skip",
  "status.loading": "Loading…",
  "status.starting": "Starting your session…",
  "status.submitting": "Submitting your answer…",
  "status.analyzing": "Analyzing your responses…",
  "status.preparing": "Preparing your summary…",
  "err.title": "Something went wrong",
  "err.offline": "We couldn't reach the CareFlow service. Please check your connection and try again.",
  "err.generic": "An unexpected error occurred. Please try again.",
  "err.noSession": "No active session was found. Let's start a new one.",
  "err.retry": "Try again",
  "err.restart": "Start over",
  "home.empty": "Please describe how you're feeling first.",
};

const ar: Dict = {
  "splash.tagline": "انتقل إلى الرعاية المناسبة بتوجيه من الذكاء الاصطناعي.",
  "splash.hipaa": "آمن HIPAA",
  "splash.ai": "مدعوم بالذكاء الاصطناعي",
  "splash.always": "٢٤ / ٧",
  "lang.title": "اختر لغتك",
  "lang.subtitle": "اختر لغتك المفضلة للمتابعة. يمكنك تغيير ذلك لاحقاً من الإعدادات.",
  "lang.ar.desc": "اللغة الافتراضية للمستخدمين في المملكة العربية السعودية",
  "lang.en.desc": "موصى بها للمستخدمين الدوليين",
  "lang.continue": "متابعة",
  "disc.title": "قبل أن نبدأ",
  "disc.subtitle": "يرجى قراءة المعلومات المهمة التالية.",
  "disc.item1.title": "التوجيه في الرعاية الصحية",
  "disc.item1.desc": "يساعدك كير فلو الذكي في تحديد الخدمة المناسبة وتوجيهك إلى مسار الرعاية الأنسب.",
  "disc.item2.title": "لا يقدم تشخيصاً للأمراض",
  "disc.item2.desc": "لا يقوم التطبيق بتشخيص الحالات الطبية أو تفسير نتائج الفحوصات السريرية.",
  "disc.item3.title": "لا يصف الأدوية",
  "disc.item3.desc": "لا يصف التطبيق أو يوصي أو يستبدل أي دواء أو خطة علاجية.",
  "disc.accept": "فهمت، متابعة",
  "home.hello": "مرحباً",
  "home.subtitle": "كيف يمكننا مساعدتك اليوم؟",
  "home.notifications": "الإشعارات",
  "home.voiceInput": "بدء الإدخال الصوتي",
  "home.assistant": "المساعد الصحي الذكي",
  "home.ready": "جاهز · جلسة آمنة",
  "home.placeholder": "صف سؤالك...",
  "home.hint": "اكتب أو استخدم الإدخال الصوتي",
  "home.start": "ابدأ التقييم الذكي",
  "home.quick": "إجراءات سريعة",
  "home.seeall": "عرض الكل",
  "home.q.symptoms": "الأعراض",
  "home.q.symptoms.desc": "صف ما تشعر به",
  "home.q.appointment": "موعد",
  "home.q.appointment.desc": "جدولة أو إدارة",
  "chat.duration": "المدة",
  "chat.q": "سؤال",
  "chat.of": "من",
  "chat.q1": "منذ متى وأنت تعاني من هذه الأعراض؟",
  "chat.a1": "أقل من ٢٤ ساعة",
  "chat.a1.desc": "بدأت مؤخراً",
  "chat.a2": "١ – ٣ أيام",
  "chat.a2.desc": "الأيام القليلة الماضية",
  "chat.a3": "٤ – ٧ أيام",
  "chat.a3.desc": "منذ حوالي أسبوع",
  "chat.a4": "أكثر من أسبوع",
  "chat.a4.desc": "مستمرة أو متكررة",
  "chat.next": "التالي",
  "reco.title": "توصية الذكاء الاصطناعي",
  "reco.complete": "اكتمل تحليل الذكاء الاصطناعي",
  "reco.urgency": "مستوى الاستعجال",
  "reco.moderate": "متوسط",
  "reco.doctor24": "راجع الطبيب خلال ٢٤ ساعة",
  "reco.service": "الخدمة الموصى بها",
  "reco.urgent": "مركز الرعاية العاجلة",
  "reco.wait": "١٨–٤٠ دقيقة انتظار",
  "reco.reason": "السبب",
  "reco.reasonText": "الأعراض التي أبلغت عنها — سعال منتج وحمى خفيفة وضيق في الصدر لمدة ٣ أيام — تتوافق مع التهاب في الجهاز التنفسي يتطلب تقييماً سريرياً وربما علاجاً بالمضادات الحيوية.",
  "reco.restart": "ابدأ جلسة جديدة",
  "reco.viewSummary": "عرض ملخص الزيارة",
  "sum.title": "ملخص الزيارة",
  "sum.subtitle": "سجل جلستك والتوصية الموجهة بالذكاء الاصطناعي.",
  "sum.saved": "تم حفظ الملخص بأمان",
  "sum.triageLabel": "فئة الفرز",
  "sum.triage.moderate": "متوسط — خلال ٢٤ ساعة",
  "sum.destLabel": "الوجهة الموصى بها",
  "sum.complaint": "الشكوى الرئيسية",
  "sum.complaintText": "سعال منتج مع حمى خفيفة وضيق في الصدر خلال الأيام الثلاثة الماضية.",
  "sum.answers": "إجاباتك",
  "sum.q2": "هل لديك حمى؟",
  "sum.a2": "نعم، خفيفة (٣٧٫٨°م)",
  "sum.q3": "هل تعاني من ضيق في التنفس؟",
  "sum.a3": "خفيف، فقط عند الحركة",
  "sum.safety": "قاعدة السلامة المُفعّلة",
  "sum.safetyText": "تم الإبلاغ عن ضيق في الصدر — تمت الإحالة إلى تقييم سريري في نفس اليوم.",
  "sum.ai": "ملخص الذكاء الاصطناعي",
  "sum.aiText": "تشير الأعراض إلى التهاب في الجهاز التنفسي بشدة متوسطة. يُنصح بالتقييم الشخصي خلال ٢٤ ساعة لاستبعاد الالتهاب الرئوي والنظر في العلاج بالمضادات الحيوية.",
  "restart.title": "اكتملت الجلسة",
  "restart.subtitle": "شكراً لاستخدامك كير فلو الذكي. تم حفظ ملخص جلستك.",
  "restart.new": "ابدأ جلسة جديدة",
  "restart.home": "العودة للرئيسية",
  "back": "رجوع",
  "skip": "تخطي",
  "status.loading": "جارٍ التحميل…",
  "status.starting": "جارٍ بدء جلستك…",
  "status.submitting": "جارٍ إرسال إجابتك…",
  "status.analyzing": "جارٍ تحليل إجاباتك…",
  "status.preparing": "جارٍ إعداد الملخص…",
  "err.title": "حدث خطأ ما",
  "err.offline": "تعذّر الوصول إلى خدمة كير فلو. يرجى التحقق من اتصالك والمحاولة مرة أخرى.",
  "err.generic": "حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.",
  "err.noSession": "لم يتم العثور على جلسة نشطة. لنبدأ جلسة جديدة.",
  "err.retry": "إعادة المحاولة",
  "err.restart": "ابدأ من جديد",
  "home.empty": "يرجى وصف ما تشعر به أولاً.",
};

const dicts: Record<Lang, Dict> = { en, ar };

type I18nCtx = { lang: Lang; setLang: (l: Lang) => void; t: (k: string) => string; dir: "ltr" | "rtl" };
const Ctx = createContext<I18nCtx | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");

  useEffect(() => {
    const saved = (typeof window !== "undefined" ? localStorage.getItem("careflow.lang") : null) as Lang | null;
    if (saved === "ar" || saved === "en") setLangState(saved);
  }, []);

  const dir = lang === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    if (typeof document !== "undefined") {
      document.documentElement.dir = dir;
      document.documentElement.lang = lang;
    }
  }, [lang, dir]);

  const setLang = (l: Lang) => {
    setLangState(l);
    if (typeof window !== "undefined") localStorage.setItem("careflow.lang", l);
  };

  const t = (k: string) => dicts[lang][k] ?? k;

  return <Ctx.Provider value={{ lang, setLang, t, dir }}>{children}</Ctx.Provider>;
}

export function useI18n() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useI18n must be used inside I18nProvider");
  return c;
}
